export { default as FloatingMenu } from './FloatingMenu';
export type { FloatingMenuProps } from './FloatingMenu';
export { default as FloatingMenuExample } from './FloatingMenuExample'; 