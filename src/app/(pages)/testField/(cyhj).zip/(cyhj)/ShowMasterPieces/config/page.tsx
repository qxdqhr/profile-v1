'use client';

import { ShowMasterPiecesConfigPage } from '@/modules/showmasterpiece';

export default ShowMasterPiecesConfigPage; 